<?php

namespace App\Entity;

use App\Repository\ContratRepository;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass=ContratRepository::class)
 */
class Contrat
{
    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="date")
     */
    private $dateDebContart;

    /**
     * @ORM\Column(type="date")
     */
    private $dateFinContrat;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $TypeContrat;

    /**
     * @ORM\Column(type="boolean")
     */
    private $etatContart;

    /**
     * @ORM\OneToOne(targetEntity=Employe::class, mappedBy="Contrat", cascade={"persist", "remove"})
     */
    private $ContratEmployes;

    /**
     * @ORM\OneToOne(targetEntity=Payement::class, inversedBy="Contrat", cascade={"persist", "remove"})
     */
    private $Payement;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getDateDebContart(): ?\DateTimeInterface
    {
        return $this->dateDebContart;
    }

    public function setDateDebContart(\DateTimeInterface $dateDebContart): self
    {
        $this->dateDebContart = $dateDebContart;

        return $this;
    }

    public function getDateFinContrat(): ?\DateTimeInterface
    {
        return $this->dateFinContrat;
    }

    public function setDateFinContrat(\DateTimeInterface $dateFinContrat): self
    {
        $this->dateFinContrat = $dateFinContrat;

        return $this;
    }

    public function getTypeContrat(): ?string
    {
        return $this->TypeContrat;
    }

    public function setTypeContrat(string $TypeContrat): self
    {
        $this->TypeContrat = $TypeContrat;

        return $this;
    }

    public function getEtatContart(): ?bool
    {
        return $this->etatContart;
    }

    public function setEtatContart(bool $etatContart): self
    {
        $this->etatContart = $etatContart;

        return $this;
    }

    public function getContratEmployes(): ?Employe
    {
        return $this->ContratEmployes;
    }

    public function setContratEmployes(Employe $ContratEmployes): self
    {
        // set the owning side of the relation if necessary
        if ($ContratEmployes->getContrat() !== $this) {
            $ContratEmployes->setContrat($this);
        }

        $this->ContratEmployes = $ContratEmployes;

        return $this;
    }

    public function getPayement(): ?Payement
    {
        return $this->Payement;
    }

    public function setPayement(?Payement $Payement): self
    {
        $this->Payement = $Payement;

        return $this;
    }
}
