<?php

namespace App\Entity;

use App\Repository\MenuRepository;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass=MenuRepository::class)
 */
class Menu
{
    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $libMenu;

    /**
     * @ORM\ManyToOne(targetEntity=Role::class, inversedBy="menus")
     */
    private $Role;

    /**
     * @ORM\ManyToOne(targetEntity=Droit::class, inversedBy="menus")
     */
    private $Droit;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getLibMenu(): ?string
    {
        return $this->libMenu;
    }

    public function setLibMenu(string $libMenu): self
    {
        $this->libMenu = $libMenu;

        return $this;
    }

    public function getMenu(): ?Role
    {
        return $this->Menu;
    }

    public function setMenu(?Role $Menu): self
    {
        $this->Menu = $Menu;

        return $this;
    }

    public function getDroit(): ?Droit
    {
        return $this->Droit;
    }

    public function setDroit(?Droit $Droit): self
    {
        $this->Droit = $Droit;

        return $this;
    }
}
