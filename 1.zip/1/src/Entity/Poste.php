<?php

namespace App\Entity;

use App\Repository\PosteRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass=PosteRepository::class)
 */
class Poste
{
    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $libPoste;

    /**
     * @ORM\OneToMany(targetEntity=Employe::class, mappedBy="Poste")
     */
    private $PosteEmployes;

    public function __construct()
    {
        $this->PosteEmployes = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getLibPoste(): ?string
    {
        return $this->libPoste;
    }

    public function setLibPoste(string $libPoste): self
    {
        $this->libPoste = $libPoste;

        return $this;
    }

    /**
     * @return Collection|Employe[]
     */
    public function getPosteEmployes(): Collection
    {
        return $this->PosteEmployes;
    }

    public function addPosteEmploye(Employe $posteEmploye): self
    {
        if (!$this->PosteEmployes->contains($posteEmploye)) {
            $this->PosteEmployes[] = $posteEmploye;
            $posteEmploye->setPoste($this);
        }

        return $this;
    }

    public function removePosteEmploye(Employe $posteEmploye): self
    {
        if ($this->PosteEmployes->removeElement($posteEmploye)) {
            // set the owning side to null (unless already changed)
            if ($posteEmploye->getPoste() === $this) {
                $posteEmploye->setPoste(null);
            }
        }

        return $this;
    }
}
