<?php

namespace App\Entity;

use App\Repository\PointageRepository;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass=PointageRepository::class)
 */
class Pointage
{
    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="time")
     */
    private $HeureArrive;

    /**
     * @ORM\Column(type="time")
     */
    private $HeureDepart;

    /**
     * @ORM\Column(type="time")
     */
    private $HeureSup;

    /**
     * @ORM\Column(type="float")
     */
    private $HeureTravaille;

    /**
     * @ORM\ManyToOne(targetEntity=Presence::class)
     */
    private $Presence;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getHeureArrive(): ?\DateTimeInterface
    {
        return $this->HeureArrive;
    }

    public function setHeureArrive(\DateTimeInterface $HeureArrive): self
    {
        $this->HeureArrive = $HeureArrive;

        return $this;
    }

    public function getHeureDepart(): ?\DateTimeInterface
    {
        return $this->HeureDepart;
    }

    public function setHeureDepart(\DateTimeInterface $HeureDepart): self
    {
        $this->HeureDepart = $HeureDepart;

        return $this;
    }

    public function getHeureSup(): ?\DateTimeInterface
    {
        return $this->HeureSup;
    }

    public function setHeureSup(\DateTimeInterface $HeureSup): self
    {
        $this->HeureSup = $HeureSup;

        return $this;
    }

    public function getHeureTravaille(): ?float
    {
        return $this->HeureTravaille;
    }

    public function setHeureTravaille(float $HeureTravaille): self
    {
        $this->HeureTravaille = $HeureTravaille;

        return $this;
    }

    public function getPresence(): ?Presence
    {
        return $this->Presence;
    }

    public function setPresence(?Presence $Presence): self
    {
        $this->Presence = $Presence;

        return $this;
    }
}
