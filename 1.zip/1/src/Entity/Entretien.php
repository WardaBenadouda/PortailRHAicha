<?php

namespace App\Entity;

use App\Repository\EntretienRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass=EntretienRepository::class)
 */
class Entretien
{
    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $LibEntretien;

    /**
     * @ORM\Column(type="boolean")
     */
    private $EtatEntretien;

    /**
     * @ORM\ManyToMany(targetEntity=Employe::class, mappedBy="Entretien")
     */
    private $ListEmloyes;

    /**
     * @ORM\OneToOne(targetEntity=Formation::class, inversedBy="Entretien", cascade={"persist", "remove"})
     */
    private $Formation;

    /**
     * @ORM\ManyToOne(targetEntity=Questionnaire::class, inversedBy="ListEntretien")
     * @ORM\JoinColumn(nullable=false)
     */
    private $Questionnaire;

    public function __construct()
    {
        $this->ListEmloyes = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getLibEntretien(): ?string
    {
        return $this->LibEntretien;
    }

    public function setLibEntretien(string $LibEntretien): self
    {
        $this->LibEntretien = $LibEntretien;

        return $this;
    }

    public function getEtatEntretien(): ?bool
    {
        return $this->EtatEntretien;
    }

    public function setEtatEntretien(bool $EtatEntretien): self
    {
        $this->EtatEntretien = $EtatEntretien;

        return $this;
    }

    /**
     * @return Collection|Employe[]
     */
    public function getListEmloyes(): Collection
    {
        return $this->ListEmloyes;
    }

    public function addListEmloye(Employe $listEmloye): self
    {
        if (!$this->ListEmloyes->contains($listEmloye)) {
            $this->ListEmloyes[] = $listEmloye;
            $listEmloye->addEntretien($this);
        }

        return $this;
    }

    public function removeListEmloye(Employe $listEmloye): self
    {
        if ($this->ListEmloyes->removeElement($listEmloye)) {
            $listEmloye->removeEntretien($this);
        }

        return $this;
    }

    public function getFormation(): ?Formation
    {
        return $this->Formation;
    }

    public function setFormation(?Formation $Formation): self
    {
        $this->Formation = $Formation;

        return $this;
    }

    public function getQuestionnaire(): ?Questionnaire
    {
        return $this->Questionnaire;
    }

    public function setQuestionnaire(?Questionnaire $Questionnaire): self
    {
        $this->Questionnaire = $Questionnaire;

        return $this;
    }
}
