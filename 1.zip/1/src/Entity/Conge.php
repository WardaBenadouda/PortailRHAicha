<?php

namespace App\Entity;

use App\Repository\CongeRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass=CongeRepository::class)
 */
class Conge
{
    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="date")
     */
    private $DateDebConge;

    /**
     * @ORM\Column(type="date")
     */
    private $DateFinConge;

    /**
     * @ORM\Column(type="boolean")
     */
    private $EtatConge;

    /**
     * @ORM\Column(type="text")
     */
    private $Note;

    /**
     * @ORM\OneToMany(targetEntity=Employe::class, mappedBy="Conge")
     */
    private $CongeEmployes;

    /**
     * @ORM\ManyToOne(targetEntity=TypeConge::class, inversedBy="ListConge")
     * @ORM\JoinColumn(nullable=false)
     */
    private $TypeConge;

    public function __construct()
    {
        $this->CongeEmployes = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getDateDebConge(): ?\DateTimeInterface
    {
        return $this->DateDebConge;
    }

    public function setDateDebConge(\DateTimeInterface $DateDebConge): self
    {
        $this->DateDebConge = $DateDebConge;

        return $this;
    }

    public function getDateFinConge(): ?\DateTimeInterface
    {
        return $this->DateFinConge;
    }

    public function setDateFinConge(\DateTimeInterface $DateFinConge): self
    {
        $this->DateFinConge = $DateFinConge;

        return $this;
    }

    public function getEtatConge(): ?bool
    {
        return $this->EtatConge;
    }

    public function setEtatConge(bool $EtatConge): self
    {
        $this->EtatConge = $EtatConge;

        return $this;
    }

    public function getNote(): ?string
    {
        return $this->Note;
    }

    public function setNote(string $Note): self
    {
        $this->Note = $Note;

        return $this;
    }

    /**
     * @return Collection|Employe[]
     */
    public function getCongeEmployes(): Collection
    {
        return $this->CongeEmployes;
    }

    public function addCongeEmploye(Employe $congeEmploye): self
    {
        if (!$this->CongeEmployes->contains($congeEmploye)) {
            $this->CongeEmployes[] = $congeEmploye;
            $congeEmploye->setConge($this);
        }

        return $this;
    }

    public function removeCongeEmploye(Employe $congeEmploye): self
    {
        if ($this->CongeEmployes->removeElement($congeEmploye)) {
            // set the owning side to null (unless already changed)
            if ($congeEmploye->getConge() === $this) {
                $congeEmploye->setConge(null);
            }
        }

        return $this;
    }

    public function getTypeConge(): ?TypeConge
    {
        return $this->TypeConge;
    }

    public function setTypeConge(?TypeConge $TypeConge): self
    {
        $this->TypeConge = $TypeConge;

        return $this;
    }
}
