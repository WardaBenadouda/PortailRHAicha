<?php

namespace App\Entity;

use App\Repository\PresenceRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass=PresenceRepository::class)
 */
class Presence
{
    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="date")
     */
    private $DateEntree;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $Type;

    /**
     * @ORM\OneToMany(targetEntity=Employe::class, mappedBy="Presence")
     */
    private $PresenceList;

    /**
     * @ORM\ManyToOne(targetEntity=Conge::class)
     */
    private $TypeCong;

    /**
     * @ORM\OneToOne(targetEntity=JourTravail::class, inversedBy="presence", cascade={"persist", "remove"})
     */
    private $JoursTravail;

    public function __construct()
    {
        $this->PresenceList = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getDateEntree(): ?\DateTimeInterface
    {
        return $this->DateEntree;
    }

    public function setDateEntree(\DateTimeInterface $DateEntree): self
    {
        $this->DateEntree = $DateEntree;

        return $this;
    }

    public function getType(): ?string
    {
        return $this->Type;
    }

    public function setType(string $Type): self
    {
        $this->Type = $Type;

        return $this;
    }

    /**
     * @return Collection|Employe[]
     */
    public function getPresenceList(): Collection
    {
        return $this->PresenceList;
    }

    public function addPresenceList(Employe $presenceList): self
    {
        if (!$this->PresenceList->contains($presenceList)) {
            $this->PresenceList[] = $presenceList;
            $presenceList->setPresence($this);
        }

        return $this;
    }

    public function removePresenceList(Employe $presenceList): self
    {
        if ($this->PresenceList->removeElement($presenceList)) {
            // set the owning side to null (unless already changed)
            if ($presenceList->getPresence() === $this) {
                $presenceList->setPresence(null);
            }
        }

        return $this;
    }

    public function getTypeCong(): ?Conge
    {
        return $this->TypeCong;
    }

    public function setTypeCong(?Conge $TypeCong): self
    {
        $this->TypeCong = $TypeCong;

        return $this;
    }

    public function getJoursTravail(): ?JourTravail
    {
        return $this->JoursTravail;
    }

    public function setJoursTravail(?JourTravail $JoursTravail): self
    {
        $this->JoursTravail = $JoursTravail;

        return $this;
    }
}
