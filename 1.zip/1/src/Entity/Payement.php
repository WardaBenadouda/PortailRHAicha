<?php

namespace App\Entity;

use App\Repository\PayementRepository;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass=PayementRepository::class)
 */
class Payement
{
    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $Salaire;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $SalaireDeBase;

    /**
     * @ORM\Column(type="date")
     */
    private $DatePayment;

    /**
     * @ORM\OneToOne(targetEntity=Contrat::class, mappedBy="Payement", cascade={"persist", "remove"})
     */
    private $Contrat;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getSalaire(): ?string
    {
        return $this->Salaire;
    }

    public function setSalaire(string $Salaire): self
    {
        $this->Salaire = $Salaire;

        return $this;
    }

    public function getSalaireDeBase(): ?string
    {
        return $this->SalaireDeBase;
    }

    public function setSalaireDeBase(string $SalaireDeBase): self
    {
        $this->SalaireDeBase = $SalaireDeBase;

        return $this;
    }

    public function getDatePayment(): ?\DateTimeInterface
    {
        return $this->DatePayment;
    }

    public function setDatePayment(\DateTimeInterface $DatePayment): self
    {
        $this->DatePayment = $DatePayment;

        return $this;
    }

    public function getContrat(): ?Contrat
    {
        return $this->Contrat;
    }

    public function setContrat(?Contrat $Contrat): self
    {
        // unset the owning side of the relation if necessary
        if ($Contrat === null && $this->Contrat !== null) {
            $this->Contrat->setPayement(null);
        }

        // set the owning side of the relation if necessary
        if ($Contrat !== null && $Contrat->getPayement() !== $this) {
            $Contrat->setPayement($this);
        }

        $this->Contrat = $Contrat;

        return $this;
    }
}
