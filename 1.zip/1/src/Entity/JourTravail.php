<?php

namespace App\Entity;

use App\Repository\JourTravailRepository;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass=JourTravailRepository::class)
 */
class JourTravail
{
    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $LibJour;

    /**
     * @ORM\OneToOne(targetEntity=Presence::class, mappedBy="JoursTravail", cascade={"persist", "remove"})
     */
    private $presence;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getLibJour(): ?string
    {
        return $this->LibJour;
    }

    public function setLibJour(string $LibJour): self
    {
        $this->LibJour = $LibJour;

        return $this;
    }

    public function getPresence(): ?Presence
    {
        return $this->presence;
    }

    public function setPresence(?Presence $presence): self
    {
        // unset the owning side of the relation if necessary
        if ($presence === null && $this->presence !== null) {
            $this->presence->setJoursTravail(null);
        }

        // set the owning side of the relation if necessary
        if ($presence !== null && $presence->getJoursTravail() !== $this) {
            $presence->setJoursTravail($this);
        }

        $this->presence = $presence;

        return $this;
    }
}
