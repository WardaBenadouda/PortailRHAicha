<?php

namespace App\Entity;

use App\Repository\QuestionnaireRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass=QuestionnaireRepository::class)
 */
class Questionnaire
{
    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $LibQuest;

    /**
     * @ORM\Column(type="float")
     */
    private $Score;

    /**
     * @ORM\OneToMany(targetEntity=Entretien::class, mappedBy="Questionnaire")
     */
    private $ListEntretien;

    /**
     * @ORM\ManyToMany(targetEntity=LesQuestions::class, inversedBy="ListQuestions")
     */
    private $Questions;

    public function __construct()
    {
        $this->ListEntretien = new ArrayCollection();
        $this->Questions = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getLibQuest(): ?string
    {
        return $this->LibQuest;
    }

    public function setLibQuest(string $LibQuest): self
    {
        $this->LibQuest = $LibQuest;

        return $this;
    }

    public function getScore(): ?float
    {
        return $this->Score;
    }

    public function setScore(float $Score): self
    {
        $this->Score = $Score;

        return $this;
    }

    /**
     * @return Collection|Entretien[]
     */
    public function getListEntretien(): Collection
    {
        return $this->ListEntretien;
    }

    public function addListEntretien(Entretien $listEntretien): self
    {
        if (!$this->ListEntretien->contains($listEntretien)) {
            $this->ListEntretien[] = $listEntretien;
            $listEntretien->setQuestionnaire($this);
        }

        return $this;
    }

    public function removeListEntretien(Entretien $listEntretien): self
    {
        if ($this->ListEntretien->removeElement($listEntretien)) {
            // set the owning side to null (unless already changed)
            if ($listEntretien->getQuestionnaire() === $this) {
                $listEntretien->setQuestionnaire(null);
            }
        }

        return $this;
    }

    /**
     * @return Collection|LesQuestions[]
     */
    public function getQuestions(): Collection
    {
        return $this->Questions;
    }

    public function addQuestion(LesQuestions $question): self
    {
        if (!$this->Questions->contains($question)) {
            $this->Questions[] = $question;
        }

        return $this;
    }

    public function removeQuestion(LesQuestions $question): self
    {
        $this->Questions->removeElement($question);

        return $this;
    }
}
