<?php

namespace App\Entity;

use App\Repository\LesQuestionsRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass=LesQuestionsRepository::class)
 */
class LesQuestions
{
    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="text")
     */
    private $Title;

    /**
     * @ORM\ManyToMany(targetEntity=Questionnaire::class, mappedBy="Questions")
     */
    private $ListQuestions;

    public function __construct()
    {
        $this->ListQuestions = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getTitle(): ?string
    {
        return $this->Title;
    }

    public function setTitle(string $Title): self
    {
        $this->Title = $Title;

        return $this;
    }

    /**
     * @return Collection|Questionnaire[]
     */
    public function getListQuestions(): Collection
    {
        return $this->ListQuestions;
    }

    public function addListQuestion(Questionnaire $listQuestion): self
    {
        if (!$this->ListQuestions->contains($listQuestion)) {
            $this->ListQuestions[] = $listQuestion;
            $listQuestion->addQuestion($this);
        }

        return $this;
    }

    public function removeListQuestion(Questionnaire $listQuestion): self
    {
        if ($this->ListQuestions->removeElement($listQuestion)) {
            $listQuestion->removeQuestion($this);
        }

        return $this;
    }
}
