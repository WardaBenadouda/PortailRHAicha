<?php

namespace App\Entity;

use App\Repository\NotificationRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass=NotificationRepository::class)
 */
class Notification
{
    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $TypeNotif;

    /**
     * @ORM\Column(type="date")
     */
    private $date;

    /**
     * @ORM\Column(type="text")
     */
    private $libNotif;

    /**
     * @ORM\ManyToMany(targetEntity=Employe::class, mappedBy="Notif")
     */
    private $NotifEmloyes;

    public function __construct()
    {
        $this->NotifEmloyes = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getTypeNotif(): ?string
    {
        return $this->TypeNotif;
    }

    public function setTypeNotif(string $TypeNotif): self
    {
        $this->TypeNotif = $TypeNotif;

        return $this;
    }

    public function getDate(): ?\DateTimeInterface
    {
        return $this->date;
    }

    public function setDate(\DateTimeInterface $date): self
    {
        $this->date = $date;

        return $this;
    }

    public function getLibNotif(): ?string
    {
        return $this->libNotif;
    }

    public function setLibNotif(string $libNotif): self
    {
        $this->libNotif = $libNotif;

        return $this;
    }

    /**
     * @return Collection|Employe[]
     */
    public function getNotifEmloyes(): Collection
    {
        return $this->NotifEmloyes;
    }

    public function addNotifEmloye(Employe $notifEmloye): self
    {
        if (!$this->NotifEmloyes->contains($notifEmloye)) {
            $this->NotifEmloyes[] = $notifEmloye;
            $notifEmloye->addNotif($this);
        }

        return $this;
    }

    public function removeNotifEmloye(Employe $notifEmloye): self
    {
        if ($this->NotifEmloyes->removeElement($notifEmloye)) {
            $notifEmloye->removeNotif($this);
        }

        return $this;
    }
}
