<?php

namespace App\Entity;

use App\Repository\RoleRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass=RoleRepository::class)
 */
class Role
{
    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $libRole;

    /**
     * @ORM\OneToMany(targetEntity=Employe::class, mappedBy="Role")
     */
    private $RoleEmployes;

    /**
     * @ORM\OneToMany(targetEntity=Menu::class, mappedBy="Menu")
     */
    private $menus;

    public function __construct()
    {
        $this->RoleEmployes = new ArrayCollection();
        $this->menus = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getLibRole(): ?string
    {
        return $this->libRole;
    }

    public function setLibRole(string $libRole): self
    {
        $this->libRole = $libRole;

        return $this;
    }

    /**
     * @return Collection|Employe[]
     */
    public function getRoleEmployes(): Collection
    {
        return $this->RoleEmployes;
    }

    public function addRoleEmploye(Employe $roleEmploye): self
    {
        if (!$this->RoleEmployes->contains($roleEmploye)) {
            $this->RoleEmployes[] = $roleEmploye;
            $roleEmploye->setRole($this);
        }

        return $this;
    }

    public function removeRoleEmploye(Employe $roleEmploye): self
    {
        if ($this->RoleEmployes->removeElement($roleEmploye)) {
            // set the owning side to null (unless already changed)
            if ($roleEmploye->getRole() === $this) {
                $roleEmploye->setRole(null);
            }
        }

        return $this;
    }

    /**
     * @return Collection|Menu[]
     */
    public function getMenus(): Collection
    {
        return $this->menus;
    }

    public function addMenu(Menu $menu): self
    {
        if (!$this->menus->contains($menu)) {
            $this->menus[] = $menu;
            $menu->setMenu($this);
        }

        return $this;
    }

    public function removeMenu(Menu $menu): self
    {
        if ($this->menus->removeElement($menu)) {
            // set the owning side to null (unless already changed)
            if ($menu->getMenu() === $this) {
                $menu->setMenu(null);
            }
        }

        return $this;
    }
}
