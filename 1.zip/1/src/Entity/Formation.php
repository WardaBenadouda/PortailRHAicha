<?php

namespace App\Entity;

use App\Repository\FormationRepository;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass=FormationRepository::class)
 */
class Formation
{
    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $LibFormation;

    /**
     * @ORM\OneToOne(targetEntity=Entretien::class, mappedBy="Formation", cascade={"persist", "remove"})
     */
    private $Entretien;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getLibFormation(): ?string
    {
        return $this->LibFormation;
    }

    public function setLibFormation(string $LibFormation): self
    {
        $this->LibFormation = $LibFormation;

        return $this;
    }

    public function getEntretien(): ?Entretien
    {
        return $this->Entretien;
    }

    public function setEntretien(?Entretien $Entretien): self
    {
        // unset the owning side of the relation if necessary
        if ($Entretien === null && $this->Entretien !== null) {
            $this->Entretien->setFormation(null);
        }

        // set the owning side of the relation if necessary
        if ($Entretien !== null && $Entretien->getFormation() !== $this) {
            $Entretien->setFormation($this);
        }

        $this->Entretien = $Entretien;

        return $this;
    }
}
