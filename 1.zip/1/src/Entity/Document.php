<?php

namespace App\Entity;

use App\Repository\DocumentRepository;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass=DocumentRepository::class)
 */
class Document
{
    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $titleDoc;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $DateCreation;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $libDoc;

    /**
     * @ORM\ManyToOne(targetEntity=CategoryDoc::class, inversedBy="documents")
     */
    private $Category;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getTitleDoc(): ?string
    {
        return $this->titleDoc;
    }

    public function setTitleDoc(string $titleDoc): self
    {
        $this->titleDoc = $titleDoc;

        return $this;
    }

    public function getDateCreation(): ?string
    {
        return $this->DateCreation;
    }

    public function setDateCreation(string $DateCreation): self
    {
        $this->DateCreation = $DateCreation;

        return $this;
    }

    public function getLibDoc(): ?string
    {
        return $this->libDoc;
    }

    public function setLibDoc(string $libDoc): self
    {
        $this->libDoc = $libDoc;

        return $this;
    }

    public function getCategory(): ?CategoryDoc
    {
        return $this->Category;
    }

    public function setCategory(?CategoryDoc $Category): self
    {
        $this->Category = $Category;

        return $this;
    }
}
