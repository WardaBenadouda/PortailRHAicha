<?php

namespace App\Entity;

use App\Repository\EmployeRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass=EmployeRepository::class)
 */
class Employe
{
    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $nom;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $prenom;

    /**
     * @ORM\Column(type="text")
     */
    private $adresse;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $NumTel;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $email;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $mdp;

    /**
     * @ORM\ManyToOne(targetEntity=Departement::class, inversedBy="DepEmployes")
     * @ORM\JoinColumn(nullable=false)
     */
    private $Departement;

    /**
     * @ORM\ManyToOne(targetEntity=Poste::class, inversedBy="PosteEmployes")
     * @ORM\JoinColumn(nullable=false)
     */
    private $Poste;

    /**
     * @ORM\ManyToMany(targetEntity=Notification::class, inversedBy="NotifEmloyes")
     */
    private $Notif;

    /**
     * @ORM\ManyToOne(targetEntity=Role::class, inversedBy="RoleEmployes")
     */
    private $Role;

    /**
     * @ORM\OneToOne(targetEntity=Contrat::class, inversedBy="ContratEmployes", cascade={"persist", "remove"})
     * @ORM\JoinColumn(nullable=false)
     */
    private $Contrat;

    /**
     * @ORM\ManyToOne(targetEntity=Presence::class, inversedBy="PresenceList")
     */
    private $Presence;

    /**
     * @ORM\ManyToOne(targetEntity=Conge::class, inversedBy="CongeEmployes")
     */
    private $Conge;

    /**
     * @ORM\ManyToMany(targetEntity=Entretien::class, inversedBy="ListEmloyes")
     */
    private $Entretien;

    public function __construct()
    {
        $this->Notif = new ArrayCollection();
        $this->Entretien = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getNom(): ?string
    {
        return $this->nom;
    }

    public function setNom(string $nom): self
    {
        $this->nom = $nom;

        return $this;
    }

    public function getPrenom(): ?string
    {
        return $this->prenom;
    }

    public function setPrenom(string $prenom): self
    {
        $this->prenom = $prenom;

        return $this;
    }

    public function getAdresse(): ?string
    {
        return $this->adresse;
    }

    public function setAdresse(string $adresse): self
    {
        $this->adresse = $adresse;

        return $this;
    }

    public function getNumTel(): ?string
    {
        return $this->NumTel;
    }

    public function setNumTel(string $NumTel): self
    {
        $this->NumTel = $NumTel;

        return $this;
    }

    public function getEmail(): ?string
    {
        return $this->email;
    }

    public function setEmail(string $email): self
    {
        $this->email = $email;

        return $this;
    }

    public function getMdp(): ?string
    {
        return $this->mdp;
    }

    public function setMdp(string $mdp): self
    {
        $this->mdp = $mdp;

        return $this;
    }

    public function getDepartement(): ?Departement
    {
        return $this->Departement;
    }

    public function setDepartement(?Departement $Departement): self
    {
        $this->Departement = $Departement;

        return $this;
    }

    public function getPoste(): ?Poste
    {
        return $this->Poste;
    }

    public function setPoste(?Poste $Poste): self
    {
        $this->Poste = $Poste;

        return $this;
    }

    /**
     * @return Collection|Notification[]
     */
    public function getNotif(): Collection
    {
        return $this->Notif;
    }

    public function addNotif(Notification $notif): self
    {
        if (!$this->Notif->contains($notif)) {
            $this->Notif[] = $notif;
        }

        return $this;
    }

    public function removeNotif(Notification $notif): self
    {
        $this->Notif->removeElement($notif);

        return $this;
    }

    public function getRole(): ?Role
    {
        return $this->Role;
    }

    public function setRole(?Role $Role): self
    {
        $this->Role = $Role;

        return $this;
    }

    public function getContrat(): ?Contrat
    {
        return $this->Contrat;
    }

    public function setContrat(Contrat $Contrat): self
    {
        $this->Contrat = $Contrat;

        return $this;
    }

    public function getPresence(): ?Presence
    {
        return $this->Presence;
    }

    public function setPresence(?Presence $Presence): self
    {
        $this->Presence = $Presence;

        return $this;
    }

    public function getConge(): ?Conge
    {
        return $this->Conge;
    }

    public function setConge(?Conge $Conge): self
    {
        $this->Conge = $Conge;

        return $this;
    }

    /**
     * @return Collection|Entretien[]
     */
    public function getEntretien(): Collection
    {
        return $this->Entretien;
    }

    public function addEntretien(Entretien $entretien): self
    {
        if (!$this->Entretien->contains($entretien)) {
            $this->Entretien[] = $entretien;
        }

        return $this;
    }

    public function removeEntretien(Entretien $entretien): self
    {
        $this->Entretien->removeElement($entretien);

        return $this;
    }
}
