<?php

namespace App\Entity;

use App\Repository\DepartementRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass=DepartementRepository::class)
 */
class Departement
{
    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $libDep;

    /**
     * @ORM\OneToMany(targetEntity=Employe::class, mappedBy="Departement")
     */
    private $DepEmployes;

    public function __construct()
    {
        $this->DepEmployes = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getLibDep(): ?string
    {
        return $this->libDep;
    }

    public function setLibDep(string $libDep): self
    {
        $this->libDep = $libDep;

        return $this;
    }

    /**
     * @return Collection|Employe[]
     */
    public function getDepEmployes(): Collection
    {
        return $this->DepEmployes;
    }

    public function addDepEmploye(Employe $depEmploye): self
    {
        if (!$this->DepEmployes->contains($depEmploye)) {
            $this->DepEmployes[] = $depEmploye;
            $depEmploye->setDepartement($this);
        }

        return $this;
    }

    public function removeDepEmploye(Employe $depEmploye): self
    {
        if ($this->DepEmployes->removeElement($depEmploye)) {
            // set the owning side to null (unless already changed)
            if ($depEmploye->getDepartement() === $this) {
                $depEmploye->setDepartement(null);
            }
        }

        return $this;
    }
}
