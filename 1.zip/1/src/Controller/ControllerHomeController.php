<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class ControllerHomeController extends AbstractController
{
    /**
     * @Route("/home", name="controller_home")
     */
    public function index(): Response
    {
        return $this->render('controller_home/index.html.twig', [
            'controller_name' => 'ControllerHomeController',
        ]);
    }

    /**
     * @Route("/base", name="controller_base")
     */
    public function base(): Response
    {
        return $this->render('base.html.twig', [
            'controller_name' => 'ControllerHomeController',
        ]);
    }
    
    /**
     * @Route("/navbar", name="navbar")
     */
    public function navbar(): Response
    {
        return $this->render('base.html.twig', [
            'controller_name' => 'ControllerHomeController',
        ]);
    }
}
