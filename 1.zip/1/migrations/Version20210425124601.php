<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20210425124601 extends AbstractMigration
{
    public function getDescription(): string
    {
        return '';
    }

    public function up(Schema $schema): void
    {
        // this up() migration is auto-generated, please modify it to your needs
        $this->addSql('CREATE TABLE category_doc (id INT AUTO_INCREMENT NOT NULL, nom_category VARCHAR(255) NOT NULL, PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE conge (id INT AUTO_INCREMENT NOT NULL, type_conge_id INT NOT NULL, date_deb_conge DATE NOT NULL, date_fin_conge DATE NOT NULL, etat_conge TINYINT(1) NOT NULL, note LONGTEXT NOT NULL, INDEX IDX_2ED89348753BDA5 (type_conge_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE contrat (id INT AUTO_INCREMENT NOT NULL, payement_id INT DEFAULT NULL, date_deb_contart DATE NOT NULL, date_fin_contrat DATE NOT NULL, type_contrat VARCHAR(255) NOT NULL, etat_contart TINYINT(1) NOT NULL, UNIQUE INDEX UNIQ_60349993868C0609 (payement_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE departement (id INT AUTO_INCREMENT NOT NULL, lib_dep VARCHAR(255) NOT NULL, PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE document (id INT AUTO_INCREMENT NOT NULL, category_id INT DEFAULT NULL, title_doc VARCHAR(255) NOT NULL, date_creation VARCHAR(255) NOT NULL, lib_doc VARCHAR(255) NOT NULL, INDEX IDX_D8698A7612469DE2 (category_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE droit (id INT AUTO_INCREMENT NOT NULL, lib_droit VARCHAR(255) NOT NULL, PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE employe (id INT AUTO_INCREMENT NOT NULL, departement_id INT NOT NULL, poste_id INT NOT NULL, role_id INT DEFAULT NULL, contrat_id INT NOT NULL, presence_id INT DEFAULT NULL, conge_id INT DEFAULT NULL, nom VARCHAR(255) NOT NULL, prenom VARCHAR(255) NOT NULL, adresse LONGTEXT NOT NULL, num_tel VARCHAR(255) NOT NULL, email VARCHAR(255) NOT NULL, mdp VARCHAR(255) NOT NULL, INDEX IDX_F804D3B9CCF9E01E (departement_id), INDEX IDX_F804D3B9A0905086 (poste_id), INDEX IDX_F804D3B9D60322AC (role_id), UNIQUE INDEX UNIQ_F804D3B91823061F (contrat_id), INDEX IDX_F804D3B9F328FFC4 (presence_id), INDEX IDX_F804D3B9CAAC9A59 (conge_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE employe_notification (employe_id INT NOT NULL, notification_id INT NOT NULL, INDEX IDX_5DE98E401B65292 (employe_id), INDEX IDX_5DE98E40EF1A9D84 (notification_id), PRIMARY KEY(employe_id, notification_id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE employe_entretien (employe_id INT NOT NULL, entretien_id INT NOT NULL, INDEX IDX_EA76D08C1B65292 (employe_id), INDEX IDX_EA76D08C548DCEA2 (entretien_id), PRIMARY KEY(employe_id, entretien_id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE entretien (id INT AUTO_INCREMENT NOT NULL, formation_id INT DEFAULT NULL, questionnaire_id INT NOT NULL, lib_entretien VARCHAR(255) NOT NULL, etat_entretien TINYINT(1) NOT NULL, UNIQUE INDEX UNIQ_2B58D6DA5200282E (formation_id), INDEX IDX_2B58D6DACE07E8FF (questionnaire_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE formation (id INT AUTO_INCREMENT NOT NULL, lib_formation VARCHAR(255) NOT NULL, PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE jour_ferie (id INT AUTO_INCREMENT NOT NULL, date DATE NOT NULL, evenement LONGTEXT NOT NULL, PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE jour_travail (id INT AUTO_INCREMENT NOT NULL, lib_jour VARCHAR(255) NOT NULL, PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE les_questions (id INT AUTO_INCREMENT NOT NULL, title LONGTEXT NOT NULL, PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE menu (id INT AUTO_INCREMENT NOT NULL, role_id INT DEFAULT NULL, droit_id INT DEFAULT NULL, lib_menu VARCHAR(255) NOT NULL, INDEX IDX_7D053A93D60322AC (role_id), INDEX IDX_7D053A935AA93370 (droit_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE notification (id INT AUTO_INCREMENT NOT NULL, type_notif VARCHAR(255) NOT NULL, date DATE NOT NULL, lib_notif LONGTEXT NOT NULL, PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE payement (id INT AUTO_INCREMENT NOT NULL, salaire VARCHAR(255) NOT NULL, salaire_de_base VARCHAR(255) NOT NULL, date_payment DATE NOT NULL, PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE pointage (id INT AUTO_INCREMENT NOT NULL, presence_id INT DEFAULT NULL, heure_arrive TIME NOT NULL, heure_depart TIME NOT NULL, heure_sup TIME NOT NULL, heure_travaille DOUBLE PRECISION NOT NULL, INDEX IDX_7591B20F328FFC4 (presence_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE poste (id INT AUTO_INCREMENT NOT NULL, lib_poste VARCHAR(255) NOT NULL, PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE presence (id INT AUTO_INCREMENT NOT NULL, type_cong_id INT DEFAULT NULL, jours_travail_id INT DEFAULT NULL, date_entree DATE NOT NULL, type VARCHAR(255) NOT NULL, INDEX IDX_6977C7A5EF4241C8 (type_cong_id), UNIQUE INDEX UNIQ_6977C7A5367D825E (jours_travail_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE questionnaire (id INT AUTO_INCREMENT NOT NULL, lib_quest VARCHAR(255) NOT NULL, score DOUBLE PRECISION NOT NULL, PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE questionnaire_les_questions (questionnaire_id INT NOT NULL, les_questions_id INT NOT NULL, INDEX IDX_9B44013FCE07E8FF (questionnaire_id), INDEX IDX_9B44013F7CF16809 (les_questions_id), PRIMARY KEY(questionnaire_id, les_questions_id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE role (id INT AUTO_INCREMENT NOT NULL, lib_role VARCHAR(255) NOT NULL, PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE type_conge (id INT AUTO_INCREMENT NOT NULL, titre VARCHAR(255) NOT NULL, lib_type_conge LONGTEXT NOT NULL, PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('ALTER TABLE conge ADD CONSTRAINT FK_2ED89348753BDA5 FOREIGN KEY (type_conge_id) REFERENCES type_conge (id)');
        $this->addSql('ALTER TABLE contrat ADD CONSTRAINT FK_60349993868C0609 FOREIGN KEY (payement_id) REFERENCES payement (id)');
        $this->addSql('ALTER TABLE document ADD CONSTRAINT FK_D8698A7612469DE2 FOREIGN KEY (category_id) REFERENCES category_doc (id)');
        $this->addSql('ALTER TABLE employe ADD CONSTRAINT FK_F804D3B9CCF9E01E FOREIGN KEY (departement_id) REFERENCES departement (id)');
        $this->addSql('ALTER TABLE employe ADD CONSTRAINT FK_F804D3B9A0905086 FOREIGN KEY (poste_id) REFERENCES poste (id)');
        $this->addSql('ALTER TABLE employe ADD CONSTRAINT FK_F804D3B9D60322AC FOREIGN KEY (role_id) REFERENCES role (id)');
        $this->addSql('ALTER TABLE employe ADD CONSTRAINT FK_F804D3B91823061F FOREIGN KEY (contrat_id) REFERENCES contrat (id)');
        $this->addSql('ALTER TABLE employe ADD CONSTRAINT FK_F804D3B9F328FFC4 FOREIGN KEY (presence_id) REFERENCES presence (id)');
        $this->addSql('ALTER TABLE employe ADD CONSTRAINT FK_F804D3B9CAAC9A59 FOREIGN KEY (conge_id) REFERENCES conge (id)');
        $this->addSql('ALTER TABLE employe_notification ADD CONSTRAINT FK_5DE98E401B65292 FOREIGN KEY (employe_id) REFERENCES employe (id) ON DELETE CASCADE');
        $this->addSql('ALTER TABLE employe_notification ADD CONSTRAINT FK_5DE98E40EF1A9D84 FOREIGN KEY (notification_id) REFERENCES notification (id) ON DELETE CASCADE');
        $this->addSql('ALTER TABLE employe_entretien ADD CONSTRAINT FK_EA76D08C1B65292 FOREIGN KEY (employe_id) REFERENCES employe (id) ON DELETE CASCADE');
        $this->addSql('ALTER TABLE employe_entretien ADD CONSTRAINT FK_EA76D08C548DCEA2 FOREIGN KEY (entretien_id) REFERENCES entretien (id) ON DELETE CASCADE');
        $this->addSql('ALTER TABLE entretien ADD CONSTRAINT FK_2B58D6DA5200282E FOREIGN KEY (formation_id) REFERENCES formation (id)');
        $this->addSql('ALTER TABLE entretien ADD CONSTRAINT FK_2B58D6DACE07E8FF FOREIGN KEY (questionnaire_id) REFERENCES questionnaire (id)');
        $this->addSql('ALTER TABLE menu ADD CONSTRAINT FK_7D053A93D60322AC FOREIGN KEY (role_id) REFERENCES role (id)');
        $this->addSql('ALTER TABLE menu ADD CONSTRAINT FK_7D053A935AA93370 FOREIGN KEY (droit_id) REFERENCES droit (id)');
        $this->addSql('ALTER TABLE pointage ADD CONSTRAINT FK_7591B20F328FFC4 FOREIGN KEY (presence_id) REFERENCES presence (id)');
        $this->addSql('ALTER TABLE presence ADD CONSTRAINT FK_6977C7A5EF4241C8 FOREIGN KEY (type_cong_id) REFERENCES conge (id)');
        $this->addSql('ALTER TABLE presence ADD CONSTRAINT FK_6977C7A5367D825E FOREIGN KEY (jours_travail_id) REFERENCES jour_travail (id)');
        $this->addSql('ALTER TABLE questionnaire_les_questions ADD CONSTRAINT FK_9B44013FCE07E8FF FOREIGN KEY (questionnaire_id) REFERENCES questionnaire (id) ON DELETE CASCADE');
        $this->addSql('ALTER TABLE questionnaire_les_questions ADD CONSTRAINT FK_9B44013F7CF16809 FOREIGN KEY (les_questions_id) REFERENCES les_questions (id) ON DELETE CASCADE');
    }

    public function down(Schema $schema): void
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->addSql('ALTER TABLE document DROP FOREIGN KEY FK_D8698A7612469DE2');
        $this->addSql('ALTER TABLE employe DROP FOREIGN KEY FK_F804D3B9CAAC9A59');
        $this->addSql('ALTER TABLE presence DROP FOREIGN KEY FK_6977C7A5EF4241C8');
        $this->addSql('ALTER TABLE employe DROP FOREIGN KEY FK_F804D3B91823061F');
        $this->addSql('ALTER TABLE employe DROP FOREIGN KEY FK_F804D3B9CCF9E01E');
        $this->addSql('ALTER TABLE menu DROP FOREIGN KEY FK_7D053A935AA93370');
        $this->addSql('ALTER TABLE employe_notification DROP FOREIGN KEY FK_5DE98E401B65292');
        $this->addSql('ALTER TABLE employe_entretien DROP FOREIGN KEY FK_EA76D08C1B65292');
        $this->addSql('ALTER TABLE employe_entretien DROP FOREIGN KEY FK_EA76D08C548DCEA2');
        $this->addSql('ALTER TABLE entretien DROP FOREIGN KEY FK_2B58D6DA5200282E');
        $this->addSql('ALTER TABLE presence DROP FOREIGN KEY FK_6977C7A5367D825E');
        $this->addSql('ALTER TABLE questionnaire_les_questions DROP FOREIGN KEY FK_9B44013F7CF16809');
        $this->addSql('ALTER TABLE employe_notification DROP FOREIGN KEY FK_5DE98E40EF1A9D84');
        $this->addSql('ALTER TABLE contrat DROP FOREIGN KEY FK_60349993868C0609');
        $this->addSql('ALTER TABLE employe DROP FOREIGN KEY FK_F804D3B9A0905086');
        $this->addSql('ALTER TABLE employe DROP FOREIGN KEY FK_F804D3B9F328FFC4');
        $this->addSql('ALTER TABLE pointage DROP FOREIGN KEY FK_7591B20F328FFC4');
        $this->addSql('ALTER TABLE entretien DROP FOREIGN KEY FK_2B58D6DACE07E8FF');
        $this->addSql('ALTER TABLE questionnaire_les_questions DROP FOREIGN KEY FK_9B44013FCE07E8FF');
        $this->addSql('ALTER TABLE employe DROP FOREIGN KEY FK_F804D3B9D60322AC');
        $this->addSql('ALTER TABLE menu DROP FOREIGN KEY FK_7D053A93D60322AC');
        $this->addSql('ALTER TABLE conge DROP FOREIGN KEY FK_2ED89348753BDA5');
        $this->addSql('DROP TABLE category_doc');
        $this->addSql('DROP TABLE conge');
        $this->addSql('DROP TABLE contrat');
        $this->addSql('DROP TABLE departement');
        $this->addSql('DROP TABLE document');
        $this->addSql('DROP TABLE droit');
        $this->addSql('DROP TABLE employe');
        $this->addSql('DROP TABLE employe_notification');
        $this->addSql('DROP TABLE employe_entretien');
        $this->addSql('DROP TABLE entretien');
        $this->addSql('DROP TABLE formation');
        $this->addSql('DROP TABLE jour_ferie');
        $this->addSql('DROP TABLE jour_travail');
        $this->addSql('DROP TABLE les_questions');
        $this->addSql('DROP TABLE menu');
        $this->addSql('DROP TABLE notification');
        $this->addSql('DROP TABLE payement');
        $this->addSql('DROP TABLE pointage');
        $this->addSql('DROP TABLE poste');
        $this->addSql('DROP TABLE presence');
        $this->addSql('DROP TABLE questionnaire');
        $this->addSql('DROP TABLE questionnaire_les_questions');
        $this->addSql('DROP TABLE role');
        $this->addSql('DROP TABLE type_conge');
    }
}
