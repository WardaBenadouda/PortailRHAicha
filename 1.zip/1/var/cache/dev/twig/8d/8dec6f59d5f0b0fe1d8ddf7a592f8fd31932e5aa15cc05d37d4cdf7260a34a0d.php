<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* security/login.html.twig */
class __TwigTemplate_7401d1e0ce0863a342ac2da3069d54753fe65647c346925c43f8eeb3bcb6256f extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'stylesheets' => [$this, 'block_stylesheets'],
            'javascripts' => [$this, 'block_javascripts'],
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "security/login.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "security/login.html.twig"));

        // line 1
        echo "
<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\">
        <title>";
        // line 6
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
        ";
        // line 9
        echo "        ";
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 18
        echo "
        ";
        // line 19
        $this->displayBlock('javascripts', $context, $blocks);
        // line 22
        echo "    </head>
    
<body>
     

";
        // line 27
        $this->displayBlock('body', $context, $blocks);
        // line 93
        echo "<style>

  body{
    background-repeat:no-repeat;
    background-size:cover;
    background-position:center;
    margin:0;
    padding:0;
    color: white;
    transition-delay: 0s;
      background-color:rgba(0,0,0,0.3);
    
    
    }
    .container{
      color: white;
      width:350px;
    margin:0 auto;
    transform: translateY(50%);
    padding:10px;
    
    
    }
    .input{
    
      color:white;
      margin:10px;
    
    }
    .input i{
      margin-left:-35px;
    }
    .ligne{
    
    width:100%;
    background-color: white;
    height:1px;
    }
    
    .input:hover  .ligne{
    
      width:100%;
      height:1px;
     color: white;
      animation-name: fills;
      animation-duration: 1s;
    }
    input{
      padding: 20px;
      border:none;
      background: none;
      color:white;
      outline: none;
    
    
    }
    input::placeholder{
      color:white;
      width:100%;
    }
    .submit{
    margin:0 auto;
      width:100%;
      padding:5px;
      background:none;
    
    
    }
    
    .submit-div{
      margin-top:20px;
    }
    .box h1{
      padding: 10px;
      border-bottom:3px solid red;
      width:90px;
    }
    .ligne-top{
      margin: 0 auto;
    width:30%;
    background-color: white;
    height:1px;
    }
    
    .ligne-down{
      margin: 0 auto;
    width:30%;
    background-color: white;
    height:1px;
    }
    .submit-div:hover .submit{
    transition-delay: 900ms;
      border-right:1px solid white;
        border-left:1px solid white;
    }
    .submit-div:hover  .ligne-top{
    width:100%;
    animation-name: fill_submit;
    animation-duration: 1s;
    }
    .submit-div:hover  .ligne-down{
    width:100%;
    animation-name: fill_submit;
    animation-duration: 1s;
    }
    @keyframes fill_submit {
      0%{
      width: 30%;
    
      }
      100%{
        width:100%;
    
      }
    }
    @keyframes fills {
      0%{
        width:0%;
    
      }
      100%{
        width:100%;
      }
    
    }
    @media only screen and (max-width:600px) {
      .container{
        color: white;
        width:95%;
    margin:0 auto;
    text-align: justify;
      }
    
    }
</style>
   
    </body>
</html>
";
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 6
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        echo "Authentificate !";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 9
    public function block_stylesheets($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 10
        echo "          
           <link rel=\"stylesheet\" href=\"https://bootswatch.com/4/lux/bootstrap.min.css\">
       <link rel=\"stylesheet\" href=\"https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css\">


          
            
        ";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 19
    public function block_javascripts($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "javascripts"));

        // line 20
        echo "            ";
        // line 21
        echo "        ";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 27
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 28
        echo "<form method=\"post\">
    ";
        // line 29
        if ((isset($context["error"]) || array_key_exists("error", $context) ? $context["error"] : (function () { throw new RuntimeError('Variable "error" does not exist.', 29, $this->source); })())) {
            // line 30
            echo "        <div class=\"alert alert-danger\">";
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans(twig_get_attribute($this->env, $this->source, (isset($context["error"]) || array_key_exists("error", $context) ? $context["error"] : (function () { throw new RuntimeError('Variable "error" does not exist.', 30, $this->source); })()), "messageKey", [], "any", false, false, false, 30), twig_get_attribute($this->env, $this->source, (isset($context["error"]) || array_key_exists("error", $context) ? $context["error"] : (function () { throw new RuntimeError('Variable "error" does not exist.', 30, $this->source); })()), "messageData", [], "any", false, false, false, 30), "security"), "html", null, true);
            echo "</div>
    ";
        }
        // line 32
        echo "
    ";
        // line 33
        if (twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 33, $this->source); })()), "user", [], "any", false, false, false, 33)) {
            // line 34
            echo "        <div class=\"mb-3\">
            You are logged in as ";
            // line 35
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 35, $this->source); })()), "user", [], "any", false, false, false, 35), "username", [], "any", false, false, false, 35), "html", null, true);
            echo ", <a href=\"";
            echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("app_logout");
            echo "\">Logout</a>
        </div>
    ";
        }
        // line 38
        echo "
 <div class=\"container\">
  <div class=\"box\">
      <h1>Se Connecter</h1>
    <div class=\"input\">
        <i class=\"fa fa-user\"></i>
      <input type=\"email\" name=\"email\" placeholder=\"Entrer Votre Email..\" value=\"";
        // line 44
        echo twig_escape_filter($this->env, (isset($context["last_username"]) || array_key_exists("last_username", $context) ? $context["last_username"] : (function () { throw new RuntimeError('Variable "last_username" does not exist.', 44, $this->source); })()), "html", null, true);
        echo "\"  id=\"inputEmail\" required autofocus>
      <div class=\"ligne\"></div>
    </div>
    <div class=\"input\">
      <i class=\"fa fa-lock\"></i>
      <input type=\"password\" name=\"password\" id=\"inputPassword\" placeholder=\"Entrer Votre Mot de Passe..\" required>
        <div class=\"ligne\"></div>

         <input type=\"hidden\" name=\"_csrf_token\"
           value=\"";
        // line 53
        echo twig_escape_filter($this->env, $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderCsrfToken("authenticate"), "html", null, true);
        echo "\" >
    </div>
  <div class=\"submit-div\">
    <div class=\"ligne-top\"></div>
  <input type=\"submit\" name=\"\" value=\"Connexion\" class=\"submit\">
  <div class=\"ligne-down\"></div>
  </div>
  </div>

  </div>













    ";
        // line 86
        echo "
    
</form>



";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "security/login.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  374 => 86,  348 => 53,  336 => 44,  328 => 38,  320 => 35,  317 => 34,  315 => 33,  312 => 32,  306 => 30,  304 => 29,  301 => 28,  291 => 27,  281 => 21,  279 => 20,  269 => 19,  252 => 10,  242 => 9,  223 => 6,  75 => 93,  73 => 27,  66 => 22,  64 => 19,  61 => 18,  58 => 9,  54 => 6,  47 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("
<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\">
        <title>{% block title %}Authentificate !{% endblock %}</title>
        {# Run `composer require symfony/webpack-encore-bundle`
           and uncomment the following Encore helpers to start using Symfony UX #}
        {% block stylesheets %}
          
           <link rel=\"stylesheet\" href=\"https://bootswatch.com/4/lux/bootstrap.min.css\">
       <link rel=\"stylesheet\" href=\"https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css\">


          
            
        {% endblock %}

        {% block javascripts %}
            {#{{ encore_entry_script_tags('app') }}#}
        {% endblock %}
    </head>
    
<body>
     

{% block body %}
<form method=\"post\">
    {% if error %}
        <div class=\"alert alert-danger\">{{ error.messageKey|trans(error.messageData, 'security') }}</div>
    {% endif %}

    {% if app.user %}
        <div class=\"mb-3\">
            You are logged in as {{ app.user.username }}, <a href=\"{{ path('app_logout') }}\">Logout</a>
        </div>
    {% endif %}

 <div class=\"container\">
  <div class=\"box\">
      <h1>Se Connecter</h1>
    <div class=\"input\">
        <i class=\"fa fa-user\"></i>
      <input type=\"email\" name=\"email\" placeholder=\"Entrer Votre Email..\" value=\"{{ last_username }}\"  id=\"inputEmail\" required autofocus>
      <div class=\"ligne\"></div>
    </div>
    <div class=\"input\">
      <i class=\"fa fa-lock\"></i>
      <input type=\"password\" name=\"password\" id=\"inputPassword\" placeholder=\"Entrer Votre Mot de Passe..\" required>
        <div class=\"ligne\"></div>

         <input type=\"hidden\" name=\"_csrf_token\"
           value=\"{{ csrf_token('authenticate') }}\" >
    </div>
  <div class=\"submit-div\">
    <div class=\"ligne-top\"></div>
  <input type=\"submit\" name=\"\" value=\"Connexion\" class=\"submit\">
  <div class=\"ligne-down\"></div>
  </div>
  </div>

  </div>













    {#
        Uncomment this section and add a remember_me option below your firewall to activate remember me functionality.
        See https://symfony.com/doc/current/security/remember_me.html

        <div class=\"checkbox mb-3\">
            <label>
                <input type=\"checkbox\" name=\"_remember_me\"> Remember me
            </label>
        </div>
    #}

    
</form>



{% endblock %}
<style>

  body{
    background-repeat:no-repeat;
    background-size:cover;
    background-position:center;
    margin:0;
    padding:0;
    color: white;
    transition-delay: 0s;
      background-color:rgba(0,0,0,0.3);
    
    
    }
    .container{
      color: white;
      width:350px;
    margin:0 auto;
    transform: translateY(50%);
    padding:10px;
    
    
    }
    .input{
    
      color:white;
      margin:10px;
    
    }
    .input i{
      margin-left:-35px;
    }
    .ligne{
    
    width:100%;
    background-color: white;
    height:1px;
    }
    
    .input:hover  .ligne{
    
      width:100%;
      height:1px;
     color: white;
      animation-name: fills;
      animation-duration: 1s;
    }
    input{
      padding: 20px;
      border:none;
      background: none;
      color:white;
      outline: none;
    
    
    }
    input::placeholder{
      color:white;
      width:100%;
    }
    .submit{
    margin:0 auto;
      width:100%;
      padding:5px;
      background:none;
    
    
    }
    
    .submit-div{
      margin-top:20px;
    }
    .box h1{
      padding: 10px;
      border-bottom:3px solid red;
      width:90px;
    }
    .ligne-top{
      margin: 0 auto;
    width:30%;
    background-color: white;
    height:1px;
    }
    
    .ligne-down{
      margin: 0 auto;
    width:30%;
    background-color: white;
    height:1px;
    }
    .submit-div:hover .submit{
    transition-delay: 900ms;
      border-right:1px solid white;
        border-left:1px solid white;
    }
    .submit-div:hover  .ligne-top{
    width:100%;
    animation-name: fill_submit;
    animation-duration: 1s;
    }
    .submit-div:hover  .ligne-down{
    width:100%;
    animation-name: fill_submit;
    animation-duration: 1s;
    }
    @keyframes fill_submit {
      0%{
      width: 30%;
    
      }
      100%{
        width:100%;
    
      }
    }
    @keyframes fills {
      0%{
        width:0%;
    
      }
      100%{
        width:100%;
      }
    
    }
    @media only screen and (max-width:600px) {
      .container{
        color: white;
        width:95%;
    margin:0 auto;
    text-align: justify;
      }
    
    }
</style>
   
    </body>
</html>
", "security/login.html.twig", "D:\\sharedSymfony\\Portail\\PortailRH\\templates\\security\\login.html.twig");
    }
}
