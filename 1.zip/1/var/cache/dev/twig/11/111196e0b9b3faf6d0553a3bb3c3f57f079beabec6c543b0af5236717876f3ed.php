<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* base.html.twig */
class __TwigTemplate_d81d5ec5f298644c4e5676bd644c848d762a40c2e4e3b7ed0798ad634b3257a2 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'stylesheets' => [$this, 'block_stylesheets'],
            'javascripts' => [$this, 'block_javascripts'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "base.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "base.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
<head>

<title>";
        // line 5
        $this->displayBlock('title', $context, $blocks);
        echo " </title>
";
        // line 6
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 13
        echo "   ";
        $this->displayBlock('javascripts', $context, $blocks);
        // line 51
        echo "</head>
<body>
  
<!--
  <div class=\"page-wrapper chiller-theme toggled\">
        <a id=\"show-sidebar\" class=\"btn btn-sm btn-dark\" href=\"#\">
          <i class=\"fas fa-bars\"></i>
        </a>
        <button class=\"btnclick\"> <i class=\"fa fa fa-th-large\" >-india-7615949353 </i></button>
-->

  <main>
  
<nav class=\"topnav\" id=\"myTopnav\">
  <a href=\"#\" class=\"active\"><i class=\"fa fa-user-circle-o\" aria-hidden=\"true\"></i></a>
  <a href=\"#\"> <i class=\"fa fa-calendar-o\" aria-hidden=\"true\"></i></i> </a>
   <a href=\"#\"><i class=\"fas fa-comment-alt\"></i> </a>
  <a href=\"#\"><i class=\"fa fa-bell\" aria-hidden=\"true\"></i></a>
   <a href=\"#\"><i class=\"fa fa-cog\" aria-hidden=\"true\"></i></a>
    
</nav>

<aside>
 <div class=\"btnclick\">
      <span class=\"fas fa-bars\"></span>
    </div>
<div class=\"sidebar left \">
    <div class=\"user-panel\">
    <div class=\"pull-left image\">
     <img src=\"https://raw.githubusercontent.com/azouaoui-med/pro-sidebar-template/gh-pages/src/img/user.jpg\" class=\"img-responsive img-rounded\" alt=\"User Image\">
        </div>
        <div class=\"pull-left info\">
          <p>Profile</p>
          <a href=\"#\"><i class=\"fa fa-circle text-success\"></i> Online</a>
        </div>
      </div>


  <ul class=\"list-sidebar bg-defoult\">
   <li> <a href=\"#\" data-toggle=\"collapse\" data-target=\"#dashboard\" class=\"collapsed active\" id='sideDashboard' > 
        <i class=\"fa fa-tachometer\"></i> <span class=\"nav-label\"> Tableau de bord </span> 
        <span class=\"fa fa-chevron-left pull-right\"></span> </a>
      <ul class=\"sub-menu collapse\" id=\"dashboard\">
        <li class=\"active\"><a href=\"#\">Congé</a></li>
        <li><a href=\"#\">Prochaines anniversaires </a></li>
        <li><a href=\"#\">Organigramme</a></li>
        <li><a href=\"#\">Alerte de fin de contrat</a></li>
        </ul>
    </li>
   

  

    <li> <a href=\"#\" data-toggle=\"collapse\" data-target=\"#RH\" class=\"collapsed active\" id=\"sideRH\">
         <i class=\"fa fa-th-large\"></i> <span class=\"nav-label\">Ressources Humaines</span> 
         <span class=\"fa fa-chevron-left pull-right\"></span> </a>
      <ul class=\"sub-menu collapse\" id=\"RH\">
        <li ><a href=\"#\">Employés</a></li>
        <li><a href=\"#\"> Congé </a></li>
        <li><a href=\"#\">Présence </a></li>
        <li><a href=\"#\"> Note interne </a></li>
        <li><a href=\"#\">Rapports </a></li>
        <li><a href=\"#\">Gestion de la formation </a></li>  
      </ul>
    </li>

    <li> <a href=\"#\"><i class=\"fa fa-diamond\"></i> <span class=\"nav-label\">Collaborateurs</span></a> </li>
    <li> <a href=\"#\"><i class=\"fa fa-files-o\"></i> <span class=\"nav-label\">Rapports</span></a> </li>

    <li> <a href=\"#\" data-toggle=\"collapse\" data-target=\"#Reglage\" class=\"collapsed active\" id=\"sidereglage\" >
        <i class=\"fa fa-cogs\"></i> <span class=\"nav-label\">Réglages </span><span class=\"fa fa-chevron-left pull-right\"></span></a>
      <ul  class=\"sub-menu collapse\" id=\"Reglage\" >
        <li><a href=\"\"> Paramétrage</a></li>
        <li><a href=\"\"> Champs personnalisés</a></li>
        <li><a href=\"\"> Notifications</a></li>
        <li><a href=\"\"> Liste des admins </a></li>
        <li><a href=\"\"> Modèles de mails </a></li>
        <li><a href=\"\"> Management de Performance  </a></li>
      </ul>
    </li>


    <li> <a href=\"#\"><i class=\"fa fa-google-plus\"></i> <span class=\"nav-label\">Réseaux sociaux</span></a> </li>
    <li> <a href=\"#\"><i class=\"fa fa-telegram\"></i> <span class=\"nav-label\">Contact</span></a> </li>
    
    <li> <a href=\"#\"><i class=\"fa fa-files-o\"></i> <span class=\"nav-label\">Other Pages</span></a> </li>
    <li> <a href=\"#\"><i class=\"fa fa-sign-out\"></i> <span class=\"nav-label\">Déconnexion</span></a> </li>
  </ul>
</div>
</aside>



</main>
<style>
@import \"https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css\";

/* width */
::-webkit-scrollbar {
    width: 8px;
  }
  
  /* Handle on hover */
  ::-webkit-scrollbar-thumb:hover {
    background: black;
  }
 
  /* Track */
  ::-webkit-scrollbar-track {
    box-shadow: inset 0 0 2px black;
    border-radius: 2px;
  }
  
  /* Handle */
  ::-webkit-scrollbar-thumb {
    background: black;
    border-radius: 2px;
  }


html {

    -webkit-text-size-adjust: 100%;
    -ms-text-size-adjust: 100%;
}
body {
    margin: 0;
}

html, body {
    width: 100%;
    height: 100%
}
article, aside, details, figcaption, figure, footer, header, main, menu, nav, section, summary {
    display: block;
}
aside {
    height:100%
}
audio, canvas, progress, video {
    display: inline-block;
    vertical-align: baseline;
}
audio:not([controls]) {
    display: none;
    height: 0;
}

a {
    background-color: transparent;
    text-decoration: none;
}
a:active, a:hover {
    outline: 0;
}

h1,h2,h3,h4,h5,h6,p,ul,ol{ margin:0px; padding:0px;}

/***********button click****/

.btnclick{
  position: absolute;
  top: 15px;
  left:220px;
  height: 45px;
  width: 45px;
  text-align: center;
  background: #1b1b1b;
  border-radius: 3px;
  cursor: pointer;
  transition: left 0.4s ease;
}
.btnclick.fliph{
  left:60px;
  content:\"\\f039\";
}
.btnclick span{
  color: white;
  font-size: 28px;
  line-height: 45px;
}
.btnclick.fliph  span:before{
  content: \"\\f00d\";
}





/***********************  TOP Bar ********************/

nav{
    float:right;
    width:70%;
     overflow: hidden;
     margin-left:0px;
     margin-right:100px;
     background-color: #000;
     margin-top:10px;

   
}

nav a {
  float:right;
  display: block;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}
nav .fa , {
color:white;
width:10px;
height:10px;
}



.sidebar{
 width:15%; 
height:100%;  
 background-color:#000;
transition: left 0.5s  ease-in-out; 
left:-225px;


 }
.bg-defoult{background-color:#222;
}
.sidebar ul{ list-style:none; margin:0px; padding:0px;height:100% ;}

.sidebar li a,.sidebar li a.collapsed.active
{ display:block; padding:8px 12px; color:#fff;
border-left:3px solid transparent;  text-decoration:none}
.sidebar li a.active{background-color:#000;border-left:5px solid #dedede ;transition: all 0.5s  ease-in-out}
.sidebar li a:hover{background-color:#000 !important; color:#1e1e1e;border-left-color:white}
.sidebar li a i{ padding-right:5px;}

.sidebar ul .sub-menu  {
    display:none;
  
}

 #dashboard.show, #Reglage.show{
  display: block;
}

.sidebar  #RH{
  display: block;
}
.sidebar ul li .sub-menu li a{ position:relative; }
.sidebar ul li .sub-menu li a:before{
    font-family: FontAwesome;
    content: \"\\f105\";
    display: inline-block;
    padding-left: 0px;
    padding-right: 10px;
    vertical-align: middle;
}
.sidebar ul li .sub-menu li a:hover:after {
    content: \"\";
    position: absolute;
    left: -5px;
    top: 0;
    width: 5px;
    background-color: #111;
    height: 100%;
}
.sidebar ul li .sub-menu li a:hover{ background-color:#222; padding-left:20px; transition: all 0.5s  ease-in-out}
.sub-menu{ border-left:5px solid #dedede;}
    .sidebar li a .nav-label,.sidebar li a .nav-label+span{ transition: all 0.5s  ease-in-out}
    

    .sidebar.fliph li a .nav-label,.sidebar.fliph li a .nav-label+span
    { display:none;transition: all 0.5s  ease-in-out}
    .sidebar.fliph {
    width: 42px;transition: all 0.5s  ease-in-out;
   
}  


.sidebar.fliph{
    left:0;
}


.sidebar.fliph li{ position:relative}
.sidebar.fliph .sub-menu {
    position: absolute;
    left: 39px;
    top: 0;
    background-color: #222;
    width: 150px;
    z-index: 100;
}


.fliph .user-panel{ display: none; }


.user-panel>.image>img {
    width: 100%;
    max-width: 45px;
    height: auto;
    
}
 .user-panel>.info>a {
    color: #fff;
}
.user-panel>.info {
    color: #fff;
}
.user-panel>.info>p {
    font-weight: 600;
    margin-bottom: 9px;
}
.user-panel {
    clear: left;
    display: block;
    float: left;
    width: 100%;
    margin-bottom: 15px;
    padding: 25px 15px;
    border-bottom: 1px solid;
}
.user-panel>.info {
    padding: 5px 5px 5px 15px;
    line-height: 1;
    position: absolute;
    left: 55px;
}

    
</style>


</body>
</html>
";
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 5
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        echo "Welcome!";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 6
    public function block_stylesheets($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 7
        echo "<link href=\"//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css\" rel=\"stylesheet\" id=\"bootstrap-css\">
<script src=\"//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js\"></script>
<script src=\"//code.jquery.com/jquery-1.11.1.min.js\"></script>
   
    <link rel=\"stylesheet\" href=\"https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css\"/>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 13
    public function block_javascripts($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "javascripts"));

        // line 14
        echo "              <script type=\"text/javascript\">
        \$(document).ready(function(){
          \$('.btnclick').click(function(){
               \$('.sidebar').toggleClass('fliph');
                \$('.btnclick').toggleClass('fliph');
         });
              });

       

       \$(document).ready(function(){

     \$('#sideRH').click(function(){
        \$('.sidebar  #RH').toggleClass(\"show\");
      //  \$('nav ul .first').toggleClass(\"rotate\");
      });
       });

  \$(document).ready(function(){

     \$('#sideDashboard').click(function(){
        \$('.sidebar  #dashboard').toggleClass(\"show\");
      //  \$('nav ul .first').toggleClass(\"rotate\");
      });
       });

        \$(document).ready(function(){

     \$('#sidereglage').click(function(){
        \$('.sidebar  #Reglage').toggleClass(\"show\");
      //  \$('nav ul .first').toggleClass(\"rotate\");
      });
       });

      
        </script>
        ";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  465 => 14,  455 => 13,  440 => 7,  430 => 6,  411 => 5,  61 => 51,  58 => 13,  56 => 6,  52 => 5,  46 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<!DOCTYPE html>
<html>
<head>

<title>{% block title %}Welcome!{% endblock %} </title>
{% block stylesheets %}
<link href=\"//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css\" rel=\"stylesheet\" id=\"bootstrap-css\">
<script src=\"//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js\"></script>
<script src=\"//code.jquery.com/jquery-1.11.1.min.js\"></script>
   
    <link rel=\"stylesheet\" href=\"https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css\"/>
{% endblock %}
   {% block javascripts %}
              <script type=\"text/javascript\">
        \$(document).ready(function(){
          \$('.btnclick').click(function(){
               \$('.sidebar').toggleClass('fliph');
                \$('.btnclick').toggleClass('fliph');
         });
              });

       

       \$(document).ready(function(){

     \$('#sideRH').click(function(){
        \$('.sidebar  #RH').toggleClass(\"show\");
      //  \$('nav ul .first').toggleClass(\"rotate\");
      });
       });

  \$(document).ready(function(){

     \$('#sideDashboard').click(function(){
        \$('.sidebar  #dashboard').toggleClass(\"show\");
      //  \$('nav ul .first').toggleClass(\"rotate\");
      });
       });

        \$(document).ready(function(){

     \$('#sidereglage').click(function(){
        \$('.sidebar  #Reglage').toggleClass(\"show\");
      //  \$('nav ul .first').toggleClass(\"rotate\");
      });
       });

      
        </script>
        {% endblock %}
</head>
<body>
  
<!--
  <div class=\"page-wrapper chiller-theme toggled\">
        <a id=\"show-sidebar\" class=\"btn btn-sm btn-dark\" href=\"#\">
          <i class=\"fas fa-bars\"></i>
        </a>
        <button class=\"btnclick\"> <i class=\"fa fa fa-th-large\" >-india-7615949353 </i></button>
-->

  <main>
  
<nav class=\"topnav\" id=\"myTopnav\">
  <a href=\"#\" class=\"active\"><i class=\"fa fa-user-circle-o\" aria-hidden=\"true\"></i></a>
  <a href=\"#\"> <i class=\"fa fa-calendar-o\" aria-hidden=\"true\"></i></i> </a>
   <a href=\"#\"><i class=\"fas fa-comment-alt\"></i> </a>
  <a href=\"#\"><i class=\"fa fa-bell\" aria-hidden=\"true\"></i></a>
   <a href=\"#\"><i class=\"fa fa-cog\" aria-hidden=\"true\"></i></a>
    
</nav>

<aside>
 <div class=\"btnclick\">
      <span class=\"fas fa-bars\"></span>
    </div>
<div class=\"sidebar left \">
    <div class=\"user-panel\">
    <div class=\"pull-left image\">
     <img src=\"https://raw.githubusercontent.com/azouaoui-med/pro-sidebar-template/gh-pages/src/img/user.jpg\" class=\"img-responsive img-rounded\" alt=\"User Image\">
        </div>
        <div class=\"pull-left info\">
          <p>Profile</p>
          <a href=\"#\"><i class=\"fa fa-circle text-success\"></i> Online</a>
        </div>
      </div>


  <ul class=\"list-sidebar bg-defoult\">
   <li> <a href=\"#\" data-toggle=\"collapse\" data-target=\"#dashboard\" class=\"collapsed active\" id='sideDashboard' > 
        <i class=\"fa fa-tachometer\"></i> <span class=\"nav-label\"> Tableau de bord </span> 
        <span class=\"fa fa-chevron-left pull-right\"></span> </a>
      <ul class=\"sub-menu collapse\" id=\"dashboard\">
        <li class=\"active\"><a href=\"#\">Congé</a></li>
        <li><a href=\"#\">Prochaines anniversaires </a></li>
        <li><a href=\"#\">Organigramme</a></li>
        <li><a href=\"#\">Alerte de fin de contrat</a></li>
        </ul>
    </li>
   

  

    <li> <a href=\"#\" data-toggle=\"collapse\" data-target=\"#RH\" class=\"collapsed active\" id=\"sideRH\">
         <i class=\"fa fa-th-large\"></i> <span class=\"nav-label\">Ressources Humaines</span> 
         <span class=\"fa fa-chevron-left pull-right\"></span> </a>
      <ul class=\"sub-menu collapse\" id=\"RH\">
        <li ><a href=\"#\">Employés</a></li>
        <li><a href=\"#\"> Congé </a></li>
        <li><a href=\"#\">Présence </a></li>
        <li><a href=\"#\"> Note interne </a></li>
        <li><a href=\"#\">Rapports </a></li>
        <li><a href=\"#\">Gestion de la formation </a></li>  
      </ul>
    </li>

    <li> <a href=\"#\"><i class=\"fa fa-diamond\"></i> <span class=\"nav-label\">Collaborateurs</span></a> </li>
    <li> <a href=\"#\"><i class=\"fa fa-files-o\"></i> <span class=\"nav-label\">Rapports</span></a> </li>

    <li> <a href=\"#\" data-toggle=\"collapse\" data-target=\"#Reglage\" class=\"collapsed active\" id=\"sidereglage\" >
        <i class=\"fa fa-cogs\"></i> <span class=\"nav-label\">Réglages </span><span class=\"fa fa-chevron-left pull-right\"></span></a>
      <ul  class=\"sub-menu collapse\" id=\"Reglage\" >
        <li><a href=\"\"> Paramétrage</a></li>
        <li><a href=\"\"> Champs personnalisés</a></li>
        <li><a href=\"\"> Notifications</a></li>
        <li><a href=\"\"> Liste des admins </a></li>
        <li><a href=\"\"> Modèles de mails </a></li>
        <li><a href=\"\"> Management de Performance  </a></li>
      </ul>
    </li>


    <li> <a href=\"#\"><i class=\"fa fa-google-plus\"></i> <span class=\"nav-label\">Réseaux sociaux</span></a> </li>
    <li> <a href=\"#\"><i class=\"fa fa-telegram\"></i> <span class=\"nav-label\">Contact</span></a> </li>
    
    <li> <a href=\"#\"><i class=\"fa fa-files-o\"></i> <span class=\"nav-label\">Other Pages</span></a> </li>
    <li> <a href=\"#\"><i class=\"fa fa-sign-out\"></i> <span class=\"nav-label\">Déconnexion</span></a> </li>
  </ul>
</div>
</aside>



</main>
<style>
@import \"https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css\";

/* width */
::-webkit-scrollbar {
    width: 8px;
  }
  
  /* Handle on hover */
  ::-webkit-scrollbar-thumb:hover {
    background: black;
  }
 
  /* Track */
  ::-webkit-scrollbar-track {
    box-shadow: inset 0 0 2px black;
    border-radius: 2px;
  }
  
  /* Handle */
  ::-webkit-scrollbar-thumb {
    background: black;
    border-radius: 2px;
  }


html {

    -webkit-text-size-adjust: 100%;
    -ms-text-size-adjust: 100%;
}
body {
    margin: 0;
}

html, body {
    width: 100%;
    height: 100%
}
article, aside, details, figcaption, figure, footer, header, main, menu, nav, section, summary {
    display: block;
}
aside {
    height:100%
}
audio, canvas, progress, video {
    display: inline-block;
    vertical-align: baseline;
}
audio:not([controls]) {
    display: none;
    height: 0;
}

a {
    background-color: transparent;
    text-decoration: none;
}
a:active, a:hover {
    outline: 0;
}

h1,h2,h3,h4,h5,h6,p,ul,ol{ margin:0px; padding:0px;}

/***********button click****/

.btnclick{
  position: absolute;
  top: 15px;
  left:220px;
  height: 45px;
  width: 45px;
  text-align: center;
  background: #1b1b1b;
  border-radius: 3px;
  cursor: pointer;
  transition: left 0.4s ease;
}
.btnclick.fliph{
  left:60px;
  content:\"\\f039\";
}
.btnclick span{
  color: white;
  font-size: 28px;
  line-height: 45px;
}
.btnclick.fliph  span:before{
  content: \"\\f00d\";
}





/***********************  TOP Bar ********************/

nav{
    float:right;
    width:70%;
     overflow: hidden;
     margin-left:0px;
     margin-right:100px;
     background-color: #000;
     margin-top:10px;

   
}

nav a {
  float:right;
  display: block;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}
nav .fa , {
color:white;
width:10px;
height:10px;
}



.sidebar{
 width:15%; 
height:100%;  
 background-color:#000;
transition: left 0.5s  ease-in-out; 
left:-225px;


 }
.bg-defoult{background-color:#222;
}
.sidebar ul{ list-style:none; margin:0px; padding:0px;height:100% ;}

.sidebar li a,.sidebar li a.collapsed.active
{ display:block; padding:8px 12px; color:#fff;
border-left:3px solid transparent;  text-decoration:none}
.sidebar li a.active{background-color:#000;border-left:5px solid #dedede ;transition: all 0.5s  ease-in-out}
.sidebar li a:hover{background-color:#000 !important; color:#1e1e1e;border-left-color:white}
.sidebar li a i{ padding-right:5px;}

.sidebar ul .sub-menu  {
    display:none;
  
}

 #dashboard.show, #Reglage.show{
  display: block;
}

.sidebar  #RH{
  display: block;
}
.sidebar ul li .sub-menu li a{ position:relative; }
.sidebar ul li .sub-menu li a:before{
    font-family: FontAwesome;
    content: \"\\f105\";
    display: inline-block;
    padding-left: 0px;
    padding-right: 10px;
    vertical-align: middle;
}
.sidebar ul li .sub-menu li a:hover:after {
    content: \"\";
    position: absolute;
    left: -5px;
    top: 0;
    width: 5px;
    background-color: #111;
    height: 100%;
}
.sidebar ul li .sub-menu li a:hover{ background-color:#222; padding-left:20px; transition: all 0.5s  ease-in-out}
.sub-menu{ border-left:5px solid #dedede;}
    .sidebar li a .nav-label,.sidebar li a .nav-label+span{ transition: all 0.5s  ease-in-out}
    

    .sidebar.fliph li a .nav-label,.sidebar.fliph li a .nav-label+span
    { display:none;transition: all 0.5s  ease-in-out}
    .sidebar.fliph {
    width: 42px;transition: all 0.5s  ease-in-out;
   
}  


.sidebar.fliph{
    left:0;
}


.sidebar.fliph li{ position:relative}
.sidebar.fliph .sub-menu {
    position: absolute;
    left: 39px;
    top: 0;
    background-color: #222;
    width: 150px;
    z-index: 100;
}


.fliph .user-panel{ display: none; }


.user-panel>.image>img {
    width: 100%;
    max-width: 45px;
    height: auto;
    
}
 .user-panel>.info>a {
    color: #fff;
}
.user-panel>.info {
    color: #fff;
}
.user-panel>.info>p {
    font-weight: 600;
    margin-bottom: 9px;
}
.user-panel {
    clear: left;
    display: block;
    float: left;
    width: 100%;
    margin-bottom: 15px;
    padding: 25px 15px;
    border-bottom: 1px solid;
}
.user-panel>.info {
    padding: 5px 5px 5px 15px;
    line-height: 1;
    position: absolute;
    left: 55px;
}

    
</style>


</body>
</html>
", "base.html.twig", "D:\\sharedSymfony\\Portail\\PortailRH\\templates\\base.html.twig");
    }
}
